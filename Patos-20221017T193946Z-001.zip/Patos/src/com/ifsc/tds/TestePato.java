package com.ifsc.tds;

public class TestePato {

	public static void main(String[] args) {
		Pato patolino = new Pato();
		Pato donald = new PatoReal();
		PatoVermelho redzin = new PatoVermelho();
		PatoBorrachudo patin = new PatoBorrachudo();
		PatoMadeirado qui = new PatoMadeirado();

		patolino.display();
		patolino.quack();
		patolino.nadar();
		donald.voar();

		System.out.println("----------------------------------------------");

		donald.display();
		donald.quack();
		donald.nadar();
		donald.voar();

		System.out.println("----------------------------------------------");

		redzin.display();
		redzin.quack();
		redzin.nadar();
		redzin.voar();

		System.out.println("----------------------------------------------");

		patin.display();
		patin.quick();
		redzin.nadar();

		System.out.println("----------------------------------------------");

		qui.display();
		qui.quack();
		qui.voar();

	}

}
