package com.ifsc.tds;

public class PatoVermelho extends Pato {

	public void display() {
		System.out.println("patp pato vermeio");
	}
}
