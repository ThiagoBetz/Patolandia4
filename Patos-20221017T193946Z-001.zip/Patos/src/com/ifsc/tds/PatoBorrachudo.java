package com.ifsc.tds;

public class PatoBorrachudo extends Pato {
	public void quick() {
		System.out.println("Quick quick");
	}
	
	public void display() {
		System.out.println("Sou um pato de borracha quick");
	}

}
