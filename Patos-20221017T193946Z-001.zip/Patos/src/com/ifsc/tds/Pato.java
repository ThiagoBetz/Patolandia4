package com.ifsc.tds;

public class Pato {
	
	public Pato() {

	}

	public void quack() {
		System.out.println("Quack");
	}
	
	public void nadar() {
		System.out.println("Estou a Nadar");
	}

	public void display() {
		System.out.println("Oi Eu Sou o Pato");
	}
	
	public void voar() {
		System.out.println("Joy Sabe Voar");
	}

}
