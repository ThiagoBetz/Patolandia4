package com.ifsc.tds;

public class PatoMadeirado extends Pato {
	public void display() {
		System.out.println("patooo de madeiira");
		
	}

}
