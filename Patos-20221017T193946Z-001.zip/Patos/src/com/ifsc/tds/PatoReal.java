package com.ifsc.tds;

public class PatoReal extends Pato{
	
	public PatoReal() {
		
	}
	public void display() {
		System.out.println("joy soy un pato real");
	}

}
